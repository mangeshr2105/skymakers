import React, { useState } from 'react';
import { Home, TrendingUp, Key } from 'lucide-react';
import { useEffect } from 'react';
import Link from 'next/link';

interface ServiceCard {
  title: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  expandedContent?: React.ReactNode;
  buttonText?: string;
}

const services: ServiceCard[] = [
  {
    title: 'Buying',
    description: 'Find your dream property with our expert buying assistance and exclusive listings.',
    icon: <Home className="w-8 h-8 text-forest" />,
    color: 'bg-forest/10',
    expandedContent: (
      <div className="mt-4 text-left">
        <p className="text-gray-600 mb-4">
          We know that buying a home is one of the biggest and most emotional decisions of your life – we'll make it as seamless as possible.
        </p>
        <p className="text-gray-600 mb-4">
          Today's home buyer is savvy thanks to information on the internet; however, the information found is sometimes generic, out-of-date or incorrect. Our Team can help you understand the local real estate in an accurate, detailed way that reflects the nuances of our competitive housing market.
        </p>
        <div className="space-y-2 mb-4">
          <p className="font-medium text-forest">We are able to:</p>
          <ul className="list-disc pl-5 space-y-1 text-gray-600">
            <li>Provide accurate information</li>
            <li>Make connections</li>
            <li>Strongly negotiate</li>
            <li>Share local expertise</li>
            <li>Strategies on pricing</li>
          </ul>
        </div>
      </div>
    ),
    buttonText: 'Start Your Journey',
  },
  {
    title: 'Selling',
    description: 'Maximize your property value with our professional selling services and market expertise.',
    icon: <TrendingUp className="w-8 h-8 text-gold" />,
    color: 'bg-gold/10',
    expandedContent: (
      <div className="mt-4 text-left">
        <p className="text-gray-600 mb-4">
          There's a lot of information out there which can seem overwhelming — before you commit, get a feel for the process. Selling your home doesn't have to disrupt your life.
        </p>
        <p className="text-gray-600 mb-4">
          When you sell your home through us, you can rest knowing you're in highly capable hands. During the process, we work with you to:
        </p>
        <div className="space-y-2 mb-4">
          <ul className="list-disc pl-5 space-y-1 text-gray-600">
            <li>Make connections</li>
            <li>Strongly negotiate</li>
            <li>Available easily</li>
            <li>Offer market insights</li>
            <li>Prepare your property</li>
            <li>Strategize on pricing</li>
          </ul>
        </div>
      </div>
    ),
    buttonText: 'Sell My Property',
  },
  {
    title: 'Renting',
    description: 'Discover the perfect rental property with our extensive portfolio and personalized service.',
    icon: <Key className="w-8 h-8 text-forest" />,
    color: 'bg-forest/10',
    expandedContent: (
      <div className="mt-4 text-left">
        <p className="text-gray-600 mb-4">
          Finding the right rental property can be challenging, whether you're new to the area or looking to upgrade. We make the process simple and stress-free with our comprehensive rental services.
        </p>
        <p className="text-gray-600 mb-4">
          Our team is dedicated to understanding your specific needs and preferences to match you with properties that truly fit your lifestyle and budget.
        </p>
        <div className="space-y-2 mb-4">
          <p className="font-medium text-forest">Our rental services include:</p>
          <ul className="list-disc pl-5 space-y-1 text-gray-600">
            <li>Personalized property search</li>
            <li>Neighborhood insights</li>
            <li>Lease negotiation</li>
            <li>Rental application assistance</li>
            <li>Move-in coordination</li>
            <li>Ongoing tenant support</li>
          </ul>
        </div>
      </div>
    ),
    buttonText: 'Find My Rental',
  },
];

export default function Services() {
  const [expandedCard, setExpandedCard] = useState<number | null>(null);
  const [isMobile, setIsMobile] = useState(true); // Start with mobile first
  
  useEffect(() => {
    // This code runs only on the client side
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    // Set initial value
    handleResize();
    
    // Add event listener
    window.addEventListener('resize', handleResize);
    
    // Cleanup
    return () => window.removeEventListener('resize', handleResize);
  }, []);
  
  const toggleCard = (index: number) => {
    setExpandedCard(expandedCard === index ? null : index);
  };
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-forest">Our Services</h2>
          <div className="w-24 h-1 bg-gold mx-auto mt-4"></div>
          <p className="mt-6 text-gray-600 max-w-2xl mx-auto">
            Comprehensive real estate solutions tailored to your needs, whether you're buying, selling, or renting.
          </p>
        </div>

        <div className="flex overflow-x-auto pb-4 mt-12 md:grid md:grid-cols-3 md:gap-8 md:overflow-visible md:pb-0">
          {services.map((service, index) => (
            <div 
              key={index}
              className={`group bg-white rounded-xl shadow-md overflow-hidden transition-all duration-700 ease-[cubic-bezier(0.25,0.1,0.25,1)] hover:shadow-xl hover:-translate-y-1 flex-shrink-0 w-[85%] md:w-auto md:flex-shrink ${
                expandedCard === index ? 'shadow-xl -translate-y-1' : ''
              } ${index < services.length - 1 ? 'mr-6' : ''} md:mr-0`}
            >
              <div 
                className="p-8 h-full flex flex-col transition-all duration-700 ease-[cubic-bezier(0.25,0.1,0.25,1)]"
                onMouseEnter={!isMobile ? () => setExpandedCard(index) : undefined}
                onMouseLeave={!isMobile ? () => setExpandedCard(null) : undefined}
                onClick={() => isMobile && toggleCard(index)}
              >
                <div className="flex-grow cursor-pointer">
                  <div className={`w-16 h-16 ${service.color} rounded-full flex items-center justify-center mb-6`}>
                    {service.icon}
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h3>
                  <p className="text-gray-600">{service.description}</p>
                </div>
                
                <div 
                  className={`mt-4 transition-all duration-700 ease-[cubic-bezier(0.25,0.1,0.25,1)] overflow-hidden ${
                    expandedCard === index ? 'max-h-[1000px] opacity-100' : 'max-h-0 opacity-0'
                  }`}
                >
                  {service.expandedContent}
                </div>
                
                {service.buttonText && (
                  <div 
                    className="mt-6 text-center"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <button 
                      className="px-6 py-2 bg-forest text-white rounded-lg hover:bg-gold hover:text-dark transition-colors duration-300"
                      onClick={(e) => {
                        e.stopPropagation();
                        window.location.href = '/contact';
                      }}
                    >
                      {service.buttonText}
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link 
            href="/services"
            className="inline-flex items-center px-8 py-3 border border-transparent text-base font-medium rounded-xl text-white bg-forest hover:bg-gold hover:text-dark transition-colors duration-300"
          >
            View All Services
            <svg className="ml-2 -mr-1 w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
              <path fillRule="evenodd" d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
            </svg>
          </Link>
        </div>
      </div>
    </section>
  );
}
